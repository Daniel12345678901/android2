package com.example.blocodenotas

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.util.AttributeSet
import android.graphics.Typeface
import android.text.Spannable
import android.widget.EditText

class RichEditText(context: Context, attrs: AttributeSet) : EditText(context, attrs) {

    private var isBold = false
    private var isItalic = false
    private var isUnderline = false

    init {
        addTextWatcher()
    }

    fun toggleBold() {
        isBold = !isBold
        toggleStyle(StyleSpan(Typeface.BOLD))
    }

    fun toggleItalic() {
        isItalic = !isItalic
        toggleStyle(StyleSpan(Typeface.ITALIC))
    }

    fun toggleUnderline() {
        isUnderline = !isUnderline
        toggleStyle(UnderlineSpan())
    }

    fun isBold(): Boolean {
        return isBold
    }

    fun isItalic(): Boolean {
        return isItalic
    }

    fun isUnderline(): Boolean {
        return isUnderline
    }

    private fun <T> toggleStyle(style: T) where T : Any {
        val start = selectionStart
        val end = selectionEnd
        val spannable = text as Spannable

        val spans = spannable.getSpans(start, end, style::class.java)
        var isStyleApplied = false

        for (span in spans) {
            if (spannable.getSpanStart(span) <= start && spannable.getSpanEnd(span) >= end) {
                spannable.removeSpan(span)
                isStyleApplied = true
            }
        }

        if (!isStyleApplied) {
            spannable.setSpan(style, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    private fun addTextWatcher() {
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                val start = selectionStart
                val end = selectionEnd

                if (isBold) {
                    s?.setSpan(StyleSpan(Typeface.BOLD), start - 1, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                }

                if (isItalic) {
                    s?.setSpan(StyleSpan(Typeface.ITALIC), start - 1, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                }

                if (isUnderline) {
                    s?.setSpan(UnderlineSpan(), start - 1, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
        })
    }
}