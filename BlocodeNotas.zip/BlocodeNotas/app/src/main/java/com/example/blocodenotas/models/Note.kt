package com.example.blocodenotas.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class TodoItem(
    val id: Int,
    val text: String,
    var isChecked: Boolean
) : Parcelable

@Parcelize
data class Note(
    val id: Int,
    val title: String,
    val content: String,
    val todoItems: MutableList<TodoItem> = mutableListOf()
) : Parcelable