package com.example.blocodenotas.models

sealed class NoteContent {
    data class Text(val content: String) : NoteContent()
    data class ToDoItem(val item: TodoItem) : NoteContent()
}