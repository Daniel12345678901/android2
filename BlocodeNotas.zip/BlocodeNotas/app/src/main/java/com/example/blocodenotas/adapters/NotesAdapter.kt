package com.example.blocodenotas.adapters

import android.widget.Filter
import android.widget.Filterable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.blocodenotas.databinding.NoteItemBinding
import com.example.blocodenotas.models.Note

class NotesAdapter(
    private val onNoteClick: (Note) -> Unit,
    private val onDeleteClick: (Note) -> Unit
) : RecyclerView.Adapter<NotesAdapter.NoteViewHolder>(), Filterable {

    private val notes = mutableListOf<Note>()
    private val allNotes = mutableListOf<Note>() // To keep track of all notes for filtering

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val binding = NoteItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NoteViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        holder.bind(notes[position], onDeleteClick)
    }

    override fun getItemCount(): Int = notes.size

    fun setNotes(newNotes: List<Note>) {
        notes.clear()
        notes.addAll(newNotes)
        allNotes.clear()
        allNotes.addAll(newNotes)
        notifyDataSetChanged()
    }

    fun addNote(note: Note) {
        notes.add(note)
        allNotes.add(note)
        notifyItemInserted(notes.size - 1)
    }

    fun updateNote(note: Note) {
        val index = notes.indexOfFirst { it.id == note.id }
        if (index != -1) {
            notes[index] = note
            allNotes[index] = note
            notifyItemChanged(index)
        }
    }

    fun removeNote(note: Note) {
        val index = notes.indexOfFirst { it.id == note.id }
        if (index != -1) {
            notes.removeAt(index)
            allNotes.removeAt(index)
            notifyItemRemoved(index)
        }
    }

    fun getNotes(): List<Note> {
        return notes
    }

    inner class NoteViewHolder(private val binding: NoteItemBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(note: Note, onDeleteClick: (Note) -> Unit) {
            binding.textViewTitle.text = note.title
            binding.textViewContent.text = note.content

            // Set the click listener for the delete button
            binding.buttonDelete.setOnClickListener {
                onDeleteClick(note)
            }

            binding.root.setOnClickListener { onNoteClick(note) }
        }
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val filteredList = if (constraint.isNullOrEmpty()) {
                    allNotes
                } else {
                    val filterPattern = constraint.toString().lowercase().trim()
                    allNotes.filter {
                        it.title.lowercase().contains(filterPattern)
                    }
                }

                val filterResults = FilterResults()
                filterResults.values = filteredList
                return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                notes.clear()
                if (results?.values is List<*>) {
                    notes.addAll(results.values as List<Note>)
                }
                notifyDataSetChanged()
            }
        }
    }
}