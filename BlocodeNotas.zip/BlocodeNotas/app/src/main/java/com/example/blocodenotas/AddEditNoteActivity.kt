package com.example.blocodenotas

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import com.example.blocodenotas.databinding.ActivityAddEditNoteBinding
import com.example.blocodenotas.models.Note

class AddEditNoteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddEditNoteBinding
    private var note: Note? = null
    private var noteId: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        // Load theme preference
        val sharedPreferences = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val isDarkTheme = sharedPreferences.getBoolean("dark_theme", false)
        if (isDarkTheme) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        super.onCreate(savedInstanceState)
        binding = ActivityAddEditNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up Toolbar
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar).setNavigationOnClickListener {
            onBackPressed()
        }

        note = intent.getParcelableExtra("note")
        if (note != null) {
            binding.editTextTitle.setText(note?.title)
            binding.editTextContent.setText(note?.content)
            noteId = note?.id ?: 0
        } else {
            noteId = getNextNoteId()
        }

        binding.buttonBold.setOnClickListener {
            binding.editTextContent.toggleBold()
            toggleButtonState(binding.buttonBold, binding.editTextContent.isBold())
        }

        binding.buttonItalic.setOnClickListener {
            binding.editTextContent.toggleItalic()
            toggleButtonState(binding.buttonItalic, binding.editTextContent.isItalic())
        }

        binding.buttonUnderline.setOnClickListener {
            binding.editTextContent.toggleUnderline()
            toggleButtonState(binding.buttonUnderline, binding.editTextContent.isUnderline())
        }

        // Set underline programmatically for the underline button
        binding.buttonUnderline.paintFlags = binding.buttonUnderline.paintFlags or Paint.UNDERLINE_TEXT_FLAG

        binding.buttonSave.setOnClickListener {
            val title = binding.editTextTitle.text.toString()
            val content = binding.editTextContent.text.toString()
            if (title.isNotEmpty() && content.isNotEmpty()) {
                val updatedNote = note?.copy(id = noteId, title = title, content = content) ?: Note(
                    id = noteId,
                    title = title,
                    content = content
                )
                val resultIntent = Intent()
                resultIntent.putExtra("note", updatedNote)
                setResult(Activity.RESULT_OK, resultIntent)
                finish()
            } else {
                // Handle empty fields appropriately, e.g., show a Toast message
            }
        }
    }

    private fun toggleButtonState(button: Button, isActive: Boolean) {
        button.backgroundTintList = if (isActive) {
            ContextCompat.getColorStateList(this, android.R.color.holo_blue_light)
        } else {
            ContextCompat.getColorStateList(this, android.R.color.darker_gray)
        }
    }

    private fun getNextNoteId(): Int {
        val sharedPreferences = getSharedPreferences("notes_app", Context.MODE_PRIVATE)
        val nextId = sharedPreferences.getInt("next_note_id", 1)
        sharedPreferences.edit().putInt("next_note_id", nextId + 1).apply()
        return nextId
    }
}