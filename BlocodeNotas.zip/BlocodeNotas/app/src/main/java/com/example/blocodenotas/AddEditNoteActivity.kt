package com.example.blocodenotas

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.blocodenotas.adapters.TodoAdapter
import com.example.blocodenotas.databinding.ActivityAddEditNoteBinding
import com.example.blocodenotas.models.Note
import com.example.blocodenotas.models.TodoItem
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView
import java.util.*

class AddEditNoteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddEditNoteBinding
    private var note: Note? = null
    private var noteId: Int = 0
    private val REQUEST_CODE_SPEECH_INPUT = 100
    private lateinit var todoAdapter: TodoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        // Load theme preference
        val sharedPreferences = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val isDarkTheme = sharedPreferences.getBoolean("dark_theme", false)
        if (isDarkTheme) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        super.onCreate(savedInstanceState)
        binding = ActivityAddEditNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up Toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener {
            onBackPressed()
        }

        note = intent.getParcelableExtra("note")
        if (note != null) {
            binding.editTextTitle.setText(note?.title)
            binding.editTextContent.setText(note?.content)
            noteId = note?.id ?: 0
            todoAdapter = TodoAdapter(note?.todoItems ?: mutableListOf())
        } else {
            noteId = getNextNoteId()
            todoAdapter = TodoAdapter(mutableListOf())
        }

        binding.recyclerViewTodo.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewTodo.adapter = todoAdapter

        binding.buttonBold.setOnClickListener {
            binding.editTextContent.toggleBold()
            toggleButtonState(binding.buttonBold, binding.editTextContent.isBold())
        }

        binding.buttonItalic.setOnClickListener {
            binding.editTextContent.toggleItalic()
            toggleButtonState(binding.buttonItalic, binding.editTextContent.isItalic())
        }

        binding.buttonUnderline.setOnClickListener {
            binding.editTextContent.toggleUnderline()
            toggleButtonState(binding.buttonUnderline, binding.editTextContent.isUnderline())
        }

        // Set underline programmatically for the underline button
        binding.buttonUnderline.paintFlags = binding.buttonUnderline.paintFlags or Paint.UNDERLINE_TEXT_FLAG

        binding.buttonVoiceInput.setOnClickListener {
            startVoiceInput()
        }

        binding.buttonSave.setOnClickListener {
            val title = binding.editTextTitle.text.toString()
            val content = binding.editTextContent.text.toString()
            if (title.isNotEmpty() && content.isNotEmpty()) {
                val updatedNote = note?.copy(
                    id = noteId,
                    title = title,
                    content = content,
                    todoItems = todoAdapter.todoItems
                ) ?: Note(
                    id = noteId,
                    title = title,
                    content = content,
                    todoItems = todoAdapter.todoItems
                )
                val resultIntent = Intent()
                resultIntent.putExtra("note", updatedNote)
                setResult(Activity.RESULT_OK, resultIntent)
                finish()
            } else {
                Toast.makeText(this, "Title and content cannot be empty", Toast.LENGTH_SHORT).show()
            }
        }

        // Add to-do item
        binding.buttonAddTodo.setOnClickListener {
            val newTodoText = binding.editTextNewTodo.text.toString()
            if (newTodoText.isNotEmpty()) {
                val newTodoItem = TodoItem(id = todoAdapter.itemCount + 1, text = newTodoText, isChecked = false)
                todoAdapter.todoItems.add(newTodoItem)
                todoAdapter.notifyItemInserted(todoAdapter.todoItems.size - 1)
                binding.editTextNewTodo.text.clear()
            } else {
                Toast.makeText(this, "To-Do item cannot be empty", Toast.LENGTH_SHORT).show()
            }
        }

        // Ensure buttons start as inactive (gray)
        toggleButtonState(binding.buttonBold, false)
        toggleButtonState(binding.buttonItalic, false)
        toggleButtonState(binding.buttonUnderline, false)
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now...")

        try {
            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT)
        } catch (e: Exception) {
            Toast.makeText(this, "Voice input is not supported on your device", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_SPEECH_INPUT && resultCode == Activity.RESULT_OK && data != null) {
            val result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (result != null && result.isNotEmpty()) {
                binding.editTextContent.append(result[0])
            }
        }
    }

    private fun toggleButtonState(button: Button, isActive: Boolean) {
        button.backgroundTintList = if (isActive) {
            ContextCompat.getColorStateList(this, R.color.colorPrimary)
        } else {
            ContextCompat.getColorStateList(this, android.R.color.darker_gray)
        }
    }



    private fun getNextNoteId(): Int {
        val sharedPreferences = getSharedPreferences("notes_app", Context.MODE_PRIVATE)
        val nextId = sharedPreferences.getInt("next_note_id", 1)
        sharedPreferences.edit().putInt("next_note_id", nextId + 1).apply()
        return nextId
    }
}