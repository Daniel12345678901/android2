package com.example.blocodenotas

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.blocodenotas.databinding.ActivityAddEditNoteBinding
import com.example.blocodenotas.models.Note

class AddEditNoteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddEditNoteBinding
    private var note: Note? = null
    private var noteId: Int = 0  // Variável para armazenar o ID da nota

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddEditNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        note = intent.getParcelableExtra("note")
        if (note != null) {
            binding.editTextTitle.setText(note?.title)
            binding.editTextContent.setText(note?.content)
            noteId = note?.id ?: 0
        } else {
            // Gerar novo ID para nova nota
            noteId = getNextNoteId()
        }

        binding.buttonSave.setOnClickListener {
            val title = binding.editTextTitle.text.toString()
            val content = binding.editTextContent.text.toString()
            if (title.isNotEmpty() && content.isNotEmpty()) {
                val updatedNote = note?.copy(id = noteId, title = title, content = content) ?: Note(
                    id = noteId,
                    title = title,
                    content = content
                )
                val resultIntent = Intent()
                resultIntent.putExtra("note", updatedNote)
                setResult(Activity.RESULT_OK, resultIntent)
                finish()
            } else {
                // Handle empty fields appropriately, e.g., show a Toast message
            }
        }
    }

    private fun getNextNoteId(): Int {
        val sharedPreferences = getSharedPreferences("notes_app", Context.MODE_PRIVATE)
        val nextId = sharedPreferences.getInt("next_note_id", 1)
        sharedPreferences.edit().putInt("next_note_id", nextId + 1).apply()
        return nextId
    }
}