package com.example.blocodenotas

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.blocodenotas.databinding.ActivityAddEditNoteBinding
import com.example.blocodenotas.models.Note

class AddEditNoteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddEditNoteBinding
    private var note: Note? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddEditNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        note = intent.getParcelableExtra("note")
        note?.let {
            binding.editTextTitle.setText(it.title)
            binding.editTextContent.setText(it.content)
        }

        binding.buttonSave.setOnClickListener {
            val title = binding.editTextTitle.text.toString()
            val content = binding.editTextContent.text.toString()
            if (title.isNotEmpty() && content.isNotEmpty()) {
                val updatedNote = note?.copy(title = title, content = content) ?: Note(
                    title = title,
                    content = content
                )
                val resultIntent = Intent()
                resultIntent.putExtra("note", updatedNote)
                setResult(Activity.RESULT_OK, resultIntent)
                finish()
            } else {
                // Handle empty fields appropriately, e.g., show a Toast message
            }
        }
    }
}