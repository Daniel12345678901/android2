package com.example.blocodenotas.adapters

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.blocodenotas.R
import com.example.blocodenotas.models.TodoItem

class TodoAdapter(val todoItems: MutableList<TodoItem>) : RecyclerView.Adapter<TodoAdapter.TodoViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TodoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_todo, parent, false)
        return TodoViewHolder(view)
    }

    override fun onBindViewHolder(holder: TodoViewHolder, position: Int) {
        val todoItem = todoItems[position]
        holder.bind(todoItem)
    }

    override fun getItemCount(): Int = todoItems.size

    class TodoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val checkBox: CheckBox = itemView.findViewById(R.id.checkBox)
        private val todoText: TextView = itemView.findViewById(R.id.todoText)

        fun bind(todoItem: TodoItem) {
            todoText.text = todoItem.text
            checkBox.isChecked = todoItem.isChecked
            toggleStrikeThrough(todoText, todoItem.isChecked)

            checkBox.setOnCheckedChangeListener { _, isChecked ->
                toggleStrikeThrough(todoText, isChecked)
                todoItem.isChecked = isChecked
            }
        }

        private fun toggleStrikeThrough(textView: TextView, isChecked: Boolean) {
            if (isChecked) {
                textView.paintFlags = textView.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            } else {
                textView.paintFlags = textView.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            }
        }
    }
}