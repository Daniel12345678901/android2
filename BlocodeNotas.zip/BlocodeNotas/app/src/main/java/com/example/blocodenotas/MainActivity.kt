package com.example.blocodenotas

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.example.blocodenotas.databinding.ActivityMainBinding
import com.example.blocodenotas.models.Note
import com.example.blocodenotas.adapters.NotesAdapter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var notesAdapter: NotesAdapter
    private val gson = Gson()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up RecyclerView with GridLayoutManager
        binding.recyclerView.layoutManager = GridLayoutManager(this, 2) // 2 columns in the grid
        notesAdapter = NotesAdapter(
            onDeleteClick = { note -> deleteNote(note) },
            onNoteClick = { note -> openEditNoteActivity(note) } // Handle note click
        )
        binding.recyclerView.adapter = notesAdapter

        binding.fabAddNote.setOnClickListener {
            val intent = Intent(this, AddEditNoteActivity::class.java)
            addNoteLauncher.launch(intent)
        }

        loadNotes()
    }

    private val addNoteLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val note: Note? = result.data?.getParcelableExtra("note")
            note?.let {
                notesAdapter.addNote(it)
                saveNotes()
            }
        }
    }

    private val editNoteLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val note: Note? = result.data?.getParcelableExtra("note")
            note?.let {
                notesAdapter.updateNote(it)
                saveNotes()
            }
        }
    }

    private fun openEditNoteActivity(note: Note) {
        val intent = Intent(this, AddEditNoteActivity::class.java).apply {
            putExtra("note", note)
        }
        editNoteLauncher.launch(intent)
    }

    private fun editNote(note: Note) {
        val intent = Intent(this, AddEditNoteActivity::class.java).apply {
            putExtra("note", note)
        }
        editNoteLauncher.launch(intent)
    }

    private fun deleteNote(note: Note) {
        notesAdapter.removeNote(note)
        saveNotes()
    }

    private fun loadNotes() {
        val sharedPreferences = getSharedPreferences("notes_app", Context.MODE_PRIVATE)
        val notesJson = sharedPreferences.getString("notes", "[]")
        val type = object : TypeToken<List<Note>>() {}.type
        val notes: List<Note> = gson.fromJson(notesJson, type)
        notesAdapter.setNotes(notes)
    }

    private fun saveNotes() {
        val sharedPreferences = getSharedPreferences("notes_app", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val notesJson = gson.toJson(notesAdapter.getNotes())
        editor.putString("notes", notesJson)
        editor.apply()
    }
}