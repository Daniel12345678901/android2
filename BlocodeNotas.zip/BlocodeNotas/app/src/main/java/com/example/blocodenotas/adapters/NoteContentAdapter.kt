package com.example.blocodenotas.adapters

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.blocodenotas.R
import com.example.blocodenotas.models.NoteContent

class NoteContentAdapter(val noteContents: MutableList<NoteContent>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val VIEW_TYPE_TEXT = 1
        private const val VIEW_TYPE_TODO = 2
    }

    override fun getItemViewType(position: Int): Int {
        return when (noteContents[position]) {
            is NoteContent.Text -> VIEW_TYPE_TEXT
            is NoteContent.ToDoItem -> VIEW_TYPE_TODO
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_TEXT -> {
                val view = LayoutInflater.from(parent.context).inflate(R.layout.item_text, parent, false)
                TextViewHolder(view)
            }
            VIEW_TYPE_TODO -> {
                val view = LayoutInflater.from(parent.context).inflate(R.layout.item_todo, parent, false)
                TodoViewHolder(view)
            }
            else -> throw IllegalArgumentException("Invalid view type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is TextViewHolder -> holder.bind(noteContents[position] as NoteContent.Text)
            is TodoViewHolder -> holder.bind(noteContents[position] as NoteContent.ToDoItem)
        }
    }

    override fun getItemCount(): Int = noteContents.size

    class TextViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val textView: TextView = itemView.findViewById(R.id.textView)

        fun bind(text: NoteContent.Text) {
            textView.text = text.content
        }
    }

    class TodoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val checkBox: CheckBox = itemView.findViewById(R.id.checkBox)
        private val todoText: TextView = itemView.findViewById(R.id.todoText)

        fun bind(todoItem: NoteContent.ToDoItem) {
            todoText.text = todoItem.item.text
            checkBox.isChecked = todoItem.item.isChecked
            toggleStrikeThrough(todoText, todoItem.item.isChecked)

            checkBox.setOnCheckedChangeListener { _, isChecked ->
                toggleStrikeThrough(todoText, isChecked)
                todoItem.item.isChecked = isChecked
            }
        }

        private fun toggleStrikeThrough(textView: TextView, isChecked: Boolean) {
            if (isChecked) {
                textView.paintFlags = textView.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            } else {
                textView.paintFlags = textView.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            }
        }
    }
}